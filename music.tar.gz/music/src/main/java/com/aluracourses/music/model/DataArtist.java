package com.aluracourses.music.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)

public record DataArtist(
        @JsonAlias("artist") String name,
        @JsonAlias("year") Double year
) {
}
