package com.aluracourses.music.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)

public record DataG(

        @JsonAlias("songs")
        List<DataMusic> musicList
) {
}
