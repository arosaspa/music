package com.aluracourses.music.main;

import com.aluracourses.music.model.DataArtist;
import com.aluracourses.music.model.DataG;
import com.aluracourses.music.model.DataMusic;
import com.aluracourses.music.service.APIconsumption;
import com.aluracourses.music.service.ConverterData;

public class main {

    private static final String URL_BASE = "https://davidpots.com/jakeworry/017%20JSON%20Grouping,%20part%203/data.json";

    private static APIconsumption apiConsumption = new APIconsumption();

    private static ConverterData converter = new ConverterData();

    public static void showTheMenu() {

        var json = apiConsumption.Get_Information(URL_BASE);

        System.out.println("The sound is: " + json);

        var data = converter.getData(json, DataG.class);

        System.out.println("The data of sound is: " + data);
    }
}
