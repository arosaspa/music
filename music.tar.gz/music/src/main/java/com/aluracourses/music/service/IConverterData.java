package com.aluracourses.music.service;

public interface IConverterData {

    <T> T getData (String json, Class<T> classs);
}
