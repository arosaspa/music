package com.aluracourses.music.service;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;

public class ConverterData implements IConverterData {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public <T> T getData(String json, Class<T> classs) {
        try {
            return objectMapper.readValue(json, classs);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

}
