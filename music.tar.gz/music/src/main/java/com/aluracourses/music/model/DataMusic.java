package com.aluracourses.music.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;
@JsonIgnoreProperties(ignoreUnknown  = true)

public record DataMusic(
        @JsonAlias("title") String title,
        @JsonAlias("artist") String artist,
       // @JsonAlias("artist") List<DataArtist> artists,
        @JsonAlias("web_url") String web,
        @JsonAlias("img_url") String img,
        @JsonAlias("year") Double year

) {


}
